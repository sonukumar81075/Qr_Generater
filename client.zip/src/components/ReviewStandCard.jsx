import { forwardRef } from "react";

const CARD_BG = "#eef6ec";
const BORDER = "#7aa688";
const PRIMARY = "#24423d";
const ACCENT = "#2f8f68";
const ACCENT_DARK = "#227354";

/** Design width in px — all layout keys derive from this via scale `s` */
export const STAND_CARD_BASE_WIDTH_PX = 320;

function StepBadge({ n, label, s }) {
  return (
    <div className="flex flex-col items-center text-center">
      <div
        className="flex items-center justify-center rounded-full border-2 bg-white font-bold"
        style={{
          width: 48 * s,
          height: 48 * s,
          borderColor: ACCENT,
          color: PRIMARY,
          fontSize: 16 * s,
          lineHeight: 1,
        }}
      >
        {n}
      </div>
      <p
        className="mt-1 font-semibold"
        style={{
          color: PRIMARY,
          fontSize: 9 * s,
          letterSpacing: "0.01em",
        }}
      >
        {label}
      </p>
    </div>
  );
}

function QrFrame({ qrDataUrl, s }) {
  const qrPx = 168 * s;
  const boxPad = 8 * s;
  return (
    <div
      className="mx-auto inline-flex items-center justify-center rounded-2xl bg-white shadow-sm"
      style={{
        padding: boxPad,
        border: `${Math.max(2, Math.round(3 * s))}px solid ${BORDER}`,
      }}
    >
      <img
        src={qrDataUrl}
        alt=""
        className="block object-contain"
        style={{ width: qrPx, height: qrPx }}
        draggable={false}
      />
    </div>
  );
}

/**
 * Print-ready vertical reward / loyalty stand card (portrait).
 * @param {number} [cardWidthPx] — total card width (default {@link STAND_CARD_BASE_WIDTH_PX})
 */
export const ReviewStandCard = forwardRef(function ReviewStandCard(
  {
    qrDataUrl,
    heading = "Scan & Earn Rewards",
    mainText = "Scan the QR code to get exciting offers and rewards",
    footerText = "Collect points on every scan and redeem exclusive rewards",
    brandLine = "",
    cardWidthPx = STAND_CARD_BASE_WIDTH_PX,
    /** Id digit(s) or token secret tail (no full URL) */
    secretText = "",
    /** Optional top brand mark (high-res PNG/SVG recommended for print) */
    brandLogoDataUrl = null,
  },
  ref
) {
  const s = cardWidthPx / STAND_CARD_BASE_WIDTH_PX;
  const padX = 20 * s;
  const showBrandLogo =
    typeof brandLogoDataUrl === "string" && brandLogoDataUrl.length > 0;
  const trimmedSecret =
    typeof secretText === "string" ? secretText.trim() : "";
  const showSecret = trimmedSecret.length > 0;
  const secretFontPx =
    trimmedSecret.length > 50 ? Math.max(6.5, 7.25 * s) : Math.max(7.5, 8 * s);

  return (
    <div
      ref={ref}
      className="relative box-border shrink-0 overflow-hidden rounded-[16px]"
      style={{
        width: cardWidthPx,
        fontFamily: "system-ui, -apple-system, Segoe UI, sans-serif",
        backgroundColor: CARD_BG,
        border: `${Math.max(1, Math.round(2 * s))}px solid ${BORDER}`,
        color: PRIMARY,
      }}
    >
      <div
        className="absolute left-0 right-0 top-0"
        style={{
          height: 14 * s,
          background: `linear-gradient(90deg, ${ACCENT_DARK}, ${ACCENT})`,
        }}
      />

      <div
        className="relative z-10"
        style={{
          paddingLeft: padX,
          paddingRight: padX,
          paddingTop: 22 * s,
          paddingBottom: 14 * s,
        }}
      >
        {showBrandLogo ? (
          <div className="mb-3 flex justify-center">
            <div
              className="inline-flex items-center justify-center rounded-xl bg-white px-3 py-2 shadow-sm"
              style={{
                minHeight: 46 * s,
                border: `${Math.max(1, s)}px solid rgba(47, 143, 104, 0.28)`,
              }}
            >
              <img
                src={brandLogoDataUrl}
                alt=""
                className="block h-auto w-auto object-contain"
                style={{
                  maxHeight: 42 * s,
                  maxWidth: Math.min(cardWidthPx - padX * 2 - 8 * s, 220 * s),
                  imageRendering: "auto",
                }}
                draggable={false}
              />
            </div>
          </div>
        ) : null}

        {brandLine?.trim() ? (
          <p
            className="mb-1 text-center font-semibold uppercase tracking-wide"
            style={{ fontSize: 10 * s, color: "rgba(36, 66, 61, 0.85)" }}
          >
            {brandLine.trim()}
          </p>
        ) : null}

        <h2
          className="text-center font-black leading-tight"
          style={{ fontSize: 16 * s, color: PRIMARY, marginTop: 0 }}
        >
          {heading}
        </h2>

        <p
          className="mx-auto mt-1 text-center font-extrabold"
          style={{
            fontSize: 18 * s,
            color: ACCENT_DARK,
            letterSpacing: "0.01em",
          }}
        >
          FREE Rewards
        </p>

        <div className="mt-3 flex justify-center">
          <QrFrame qrDataUrl={qrDataUrl} s={s} />
        </div>

        <div className="mt-2 flex justify-center">
          <div
            className="rounded-full px-4 py-1.5 font-bold"
            style={{
              backgroundColor: "rgba(47, 143, 104, 0.12)",
              border: `${Math.max(1, s)}px solid rgba(47, 143, 104, 0.5)`,
              color: ACCENT_DARK,
              fontSize: 9.5 * s,
            }}
          >
            Scan Here Now
          </div>
        </div>

        {showSecret ? (
          <p
            className="mt-1 break-all text-center font-mono"
            style={{
              fontSize: secretFontPx,
              lineHeight: 1.3,
              color: "rgba(36, 66, 61, 0.8)",
              letterSpacing: "0.02em",
            }}
          >
            {trimmedSecret}
          </p>
        ) : null}

        <p
          className="mx-auto mt-3 text-center font-semibold leading-snug"
          style={{
            maxWidth: 270 * s,
            color: PRIMARY,
            fontSize: 13.5 * s,
          }}
        >
          {mainText}
        </p>

        <div className="mt-3 flex items-start justify-between px-1">
          <StepBadge n="1" label="Scan" s={s} />
          <StepBadge n="2" label="Collect" s={s} />
          <StepBadge n="3" label="Reward" s={s} />
        </div>

        <div
          className="mt-3 rounded-lg px-3 py-2 text-center font-extrabold"
          style={{
            background: `linear-gradient(90deg, ${ACCENT_DARK}, ${ACCENT})`,
            color: "#f4f8e8",
            fontSize: 13 * s,
            letterSpacing: "0.02em",
          }}
        >
          Start Earning Today!
        </div>

        <p
          className="mx-auto mt-2 text-center leading-relaxed"
          style={{
            maxWidth: 258 * s,
            color: "rgba(36, 66, 61, 0.76)",
            fontSize: 10 * s,
          }}
        >
          {footerText}
        </p>
      </div>
    </div>
  );
});

ReviewStandCard.displayName = "ReviewStandCard";
